# exercises 6-1

# store a persons information


person_1 = {'username': 'hpcampbell',
        'age': str(25),
        'first_name': 'Harrison',
        'last_name': 'Campbell',
        'city': 'unknown',
        },

person_2 = {'username':'mgcampbell',
        'age': str(23),
        'first_name': 'Madeleine',
        'last_name': 'Campbell',
        'city': 'Chicago',
        },
        
person_3 = {'username':'dbailey',
        'age': str(23),
        'first_name': 'Dorian',
        'last_name': 'Bailey',
        'city': 'Chicago',
        }

people = [person_1, person_2, person_3]

for person in people:
    print(person)
    

# exercises 6-2

favorite_numbers = {
    'omar': [str(10), str(5)],
    'michal': [str(13), str(4)],
    'madeleine': [str(18), str(2)],
    'harrison': [str(4), str(16)],
    'harry': [str(12), str(23)]
    }

for person, numbers in favorite_numbers.items():
    print("\n" + person.title() + "'s favorite numbers are:")
    for number in numbers:
        print("\t" + number)


# exercise 6-3

# glossary = {
    # 'loop': 'A function that allows one, or more than one,\n' +
    # "actions to be taken on each item in a list.",
    
    # 'if statement': 'A function that allows you to examine\nthe ' +
    # 'current state of a program and respond according.',
        
    # 'list': 'A collection of items in a particular order.',

    # 'string': 'A simple collection of characters.',
    
    # 'dictionary': 'A collection of key-value pairs.',
        
    # 'set': 'A list of unique items.',
        
    # 'sorted': 'A function to get a copy of keys in order.',
        
    # 'key-value pair': 'A set of values associated with each other.',
        
    # 'conditional test': 'An expresion that can be evaluated as True ' +
    # 'or False.',
    
    # 'Boolean Expression': 'Another name for conditional test.',
        
    # 'slice': 'A specific group of items in a list.'
    # }
    
# print("Loop:\n" + glossary['loop'] + "\n")
# print("if Statement:\n" + glossary['if statement'] + "\n")
# print("List:\n" + glossary['list'] + "\n")
# print("String:\n" + glossary['string'] + "\n")
# print("Dictionary:\n" + glossary['dictionary'] + "\n")

# 6-4

# for word, definition in glossary.items():
    # print(word + "\n" + definition + "\n")

# 6-5

# rivers = {
    # 'mississippi': 'United States',
    # 'nile': 'egypt',
    # 'rhine': 'germany',
    # 'thames': 'UK',
    # 'amazon': 'brazil'
    # }
    
# for river, country in rivers.items():
    # print("The " + river.title() + " runs through " + country.title()+ ".")

# for river in rivers:
    # print(river.title())
    
# for country in rivers.values():
    # print(country.title())











