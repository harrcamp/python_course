pets = {
    'spot': { 
        'age': str(2),
        'animal': 'dog',
        'owner': 'Harrison Campbell',
        'city': 'unknown',
        },

    'scruffy': {
        'age': str(3),
        'animal': 'cat',
        'owner': 'John Grube',
        'city': 'Kansas City',
        },
        
    'daisy': {
        'age': str(7),
        'animal': 'parrot',
        'owner': 'Madeleine Campbell',
        'city': 'Chicago',
        }
    }

for pet_name, pet_info in pets.items():
    print("\nName: " + pet_name.title())
    animal_type = pet_info['animal']
    age = pet_info['age']
    location = pet_info['city']
    owner = pet_info['owner']
    
    print("\tAnimal Type: " + animal_type)
    print("\tAge: " + age)
    print("\tLocation: " + location + "\n")
