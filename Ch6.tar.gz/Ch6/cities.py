# 6-11 cities

cities = {
    'chicago': {
        'population': '2.716',
        'location': 'illinois',
        'fact': 'best hot dogs',
        },
    'new york': {
        'population': '8.623',
        'location': 'new york',
        'fact': 'best pizza',
        },
    'la': {
        'population': '4.000',
        'location': 'california',
        'fact': 'best weather',
        },
    'philly': {
        'population': '',
        'location': 'pennsylvania',
        'fact': 'best sports',
        }
    }
for city, city_info in sorted(cities.items()):
    if city == 'la':
        print("\nCity: " + city.upper())
    else:
        print("\nCity: " + city.title())

    citizens = city_info['population']
    state = city_info['location']
    best = city_info['fact']
    
    if citizens == '':
        print("The population of " + city.title() + " is not known.")
    else:
        print("This city has a population of about " + citizens + ".")
   
    print("It is located in " + state.title() + 
    " and has the " + best + ".")
