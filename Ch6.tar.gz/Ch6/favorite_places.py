# 6-9 favorite places

favorite_places = {
    'harry': ['chicago', 'kansas city', 'new york'],
    'harrison': ['monaco', 'paris'],
    'harrcamp': ['outlook partners','some server rack']
    }
    
for name, places in favorite_places.items():
    print("\n" + name.title() + "'s favorite places are:")
    for place in places:
        print("\t" + place.title())
    

    
    
    
    
