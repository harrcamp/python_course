# dictionary of similar objects

favorite_languages = {
    'jen': ['python', 'ruby'],
    'sarah': ['c'],
    'edward': ['ruby', 'go'],
    'phil': ['python', 'haskell'],
    }

# access one key in the dictionary
# print("Sarah's favorite language is " +
    # favorite_languages['sarah'].title() +
    # ".")

# loop through all keys and value pairs in the dictionary
for name, languages in favorite_languages.items():
    if len(languages) > 1:
        print("\n" + name.title() + "'s favorite languages are:")
        for language in languages:
            print("\t" + language.title())
    else:
        print("\n" + name.title() + "'s favorite language is:")
        for language in languages:
            print("\t" + language.title())

# loop through all values in a dictionary with no repeats
# print("The following languages have been mentioned:")
# for language in set(favorite_languages.values()):
    # print(language.title())


# # list inside a dictionary
# friends = ['phil', 'sarah']
# for name in favorite_languages.keys():
    # print(name.title())
    
    # if name in friends:
        # print(" Hi " + name.title() +
            # ", I see your favorite language is " + 
            # favorite_languages[name].title() + "!")

# # check if erin is in the dictionary
# if 'erin' not in favorite_languages:
    # print("Erin, please take our poll!")

# # print keys and value pairs in alphabetical order    
# for name in sorted(favorite_languages):
    # print(name.title() + ", thank you for taking the poll.")


# 6-6 polling

# take_poll = ['jen', 'jake', 'sarah']
# for name in favorite_languages:
    # if name in take_poll:
        # print('Thank you ' + name.title() + ' for taking the poll.')
    # else:
        # print('Hi ' + name.title() + ',' +
        # ' we would like you to take this poll!')











