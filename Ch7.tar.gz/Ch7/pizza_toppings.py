# pizza toppings 

prompt = "\nWhat do you want on your pizza? "
prompt += "\nEnter 'order done' when you are done. "

while True:
    topping = input(prompt)
    if topping == 'order done':
        break
    else:
        print("We will add " + topping + " to your pizza.")
