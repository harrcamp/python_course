# ch 7 exercises 

# 7-1

# rental_car = input("What kind of rental car would you like?: ")

# print("Let me see if I can find you a " + rental_car.title() + ".")

# 7-2

# dinner_group = input("How many people are in your group?: ")
# dinner_group = int(dinner_group)

# if dinner_group >= 8:
    # print("There will be a bit of a wait.")
# else:
    # print("Your table is ready.")

# 7-3

# number = input("What number is it?: ")
# number = int(number)

# if number % 10 == 0:
    # print("\nThe number " + str(number) + " is a multiple of 10.")
# else:
    # print("\nThe number " + str(number) + " is not a multiple of 10.")

# 7-4

# prompt = "\nWhat do you want on your pizza? "
# prompt += "\nEnter 'order done' when you are done. "

# while True:
    # topping = input(prompt)
    # if topping == 'order done':
        # break
    # else:
        # print("We will add " + topping + " to your pizza.")
        
# 7-5

# active = True
# while active:
    # age = input("\nHow old are you?: ")
    # age = int(age)

    # if age <= 3:
        # print("\nYour ticket cost is free.")
    # elif age > 3 and age <= 12:
        # print("\nYour ticket is $10.")    
    # else:
        # print("\nYour ticket is $15.")

# 7-6
# conditional test flag

# prompt = "\nWhat do you want on your pizza? "
# prompt += "\nEnter 'order done' when you are done. "

# topping_number = 0
# while topping_number < 3:

    # topping = input(prompt)
    # if topping == 'order done':
        # break
    # else:
        # print("We will add " + topping + " to your pizza.")
    # topping_number += 1
    # if topping_number <= 3:
        # continue 
     
        
# active variable flag
        
# prompt = "\nWhat do you want on your pizza? "
# prompt += "\nEnter 'order done' when you are done. "

# active = True

# topping_number = 0
# while topping_number < 3 and active:

    # topping = input(prompt)
    # if topping == 'order done':
        # break
    # else:
        # print("We will add " + topping + " to your pizza.")
    # topping_number += 1
    # if topping_number <= 3:
        # active = True
    # else:
        # active = False


# break statement flag

# prompt = "\nWhat do you want on your pizza? "
# prompt += "\nEnter 'order done' when you are done. "

# topping_number = 0
# while topping_number < 3:

    # topping = input(prompt)
    # if topping == 'order done':
        # break
    # else:
        # print("We will add " + topping + " to your pizza.")
    # topping_number += 1
    # if topping_number <= 3:
        # continue
    # else:
        # break
        
# 7-7 infinity

# x = 1
# while x == 1:
    # print(x)
    

# 7-8 sandwich orders

# sandwich_orders = ['ham','turkey','B.L.T.', 'pastrami', 'pastrami', 'pastrami']
# finished_sandwiches = []

# print("Sorry, out of pastrami today.\n")
# while 'pastrami' in sandwich_orders:
    # sandwich_orders.remove('pastrami')


# while sandwich_orders:
    # sandwich_being_made = sandwich_orders.pop()
    
    # print("Making a " + sandwich_being_made + " sandwich.")
    # finished_sandwiches.append(sandwich_being_made)
        
# print("\nWe made all the below sandwiches in the order:")
# for finished_sandwich in finished_sandwiches:
    # print(finished_sandwich)
        
        
# 7-9 (edited 7-8)

# 7-10
# vacation poll

responses = {}

# Set a flag to indicate that polling is active.
polling_active = True

while polling_active:
    # Prompt for the person's name and response
    name = input("\nWhat is your name? ")
    response = input("What is your dream vacation? ")
    
    #store the response in the dictionary.
    responses[name] = response
    
    # Find out if anyone else is going to take the poll.
    repeat = input("Would you like to let another person respond? (yes/ no) ")
    if repeat == 'no':
        polling_active = False
        
# Polling is now complete. Show the results.
print("\n--- Poll Results ---")
for name, response in responses.items():
    print(name + " would like to visit " + response + ".")
        
        
        
        
        
        
        
        
        
        
        
        
        
        
