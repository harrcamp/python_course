# restaurant instance

from restaurant import Restaurant

# jenis = IceCreamStand("Jeni's",'ice cream',1000)
# jenis.show_flavors()

#   ORIGINAL INSTANCE
restaurant = Restaurant('the kitchen', 'stoner food', 0)
restaurant.describe_restaurant()
restaurant.increment_number_served(200)
restaurant.set_number_served()


# 9-2

# restaurant_1 = Restaurant("Parsons's", 'hot chicken')
# restaurant_2 = Restaurant("Missy's", 'italian')
# restaurant_3 = Restaurant("Harry's", 'comfort')

# restaurant_1.describe_restaurant()
# restaurant_2.describe_restaurant()
# restaurant_3.describe_restaurant()
