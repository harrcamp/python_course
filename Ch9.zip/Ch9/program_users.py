# call userr admin

from users import User
from admin_user import Admin, Privileges

admin_1 = Admin('harry', 'campbell', 25, 'chicago', 'yes')
user_2 = User('michal', 'gruber', 27, 'chicago', 'yes')
user_3 = User('omar', 'khan', 23, 'chicago', 'yes')
user_4 = User('carson', 'bricco', 24, 'chicago', 'why not')

admin_1.privileges.show_privileges()
