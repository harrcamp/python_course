
# 9-3

class User():
    """simulate the user of a program"""
    
    def __init__(self, first_name, last_name, age, location, worthy):
        """initialize the first and last name of users of the program"""
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.location = location
        self.worthy = worthy
        self.login_attempts = -1
    
    def user_summary(self):
        print("First Name - " + self.first_name.title() +
        "\nLast Name - " + self.last_name.title() +
        "\nAge - " + str(self.age) +
        "\nLocation - " + self.location.title() +
        "\nWorthy? - " + self.worthy.title())
        
    def greet_user(self):
        print("\nHello " + self.first_name.title() + "!")
        
    def increment_login_attempts(self):
        """add one login attempt after user attempts to login"""
        self.login_attempts += 1
        print(self.login_attempts)
        
    def reset_login_attempts(self):
        """reset login attempts"""
        self.login_attempts = 0
        print(self.login_attempts)
        

