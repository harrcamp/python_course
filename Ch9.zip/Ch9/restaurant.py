# restaurant file



class Restaurant():
    """model of a restuarant"""
    
    def __init__(self, restaurant_name, cuisine_type, number_served):
        """initialize restaurant name and cuisine type attributes"""
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type
        self.number_served = 0
    
    def describe_restaurant(self):
        """desctibe the restaurant"""
        print("The name of this restaurant is " + 
        self.restaurant_name.title() + ".")
        print("The cuisine at this restaurant is " +
        self.cuisine_type + ".")
    
    def restaurant_open(self):
        """simulate that the restaurant is open"""
        print(self.restaurant_name.title() + " is now open.")
        
    def set_number_served(self):
        """set number of guests the restaurant has served"""
        print("This restaurant has served " + str(self.number_served) +
        " guests.")
    
    def increment_number_served(self, customers):
        """increment the number of customers served in a day"""
        self.number_served = customers
            
class IceCreamStand(Restaurant):
    """model an icecream stand"""
    
    def __init__(self, restaurant_name, cuisine_type, number_served):
        """initialize attributes of the parent class.
        then initialize attributes specific to an electric car.
        """
        super().__init__(restaurant_name, cuisine_type, number_served)
        varieties = ['chocolate', 'vanilla', 'strawberry']
        self.flavors = varieties
            
    def show_flavors(self):
        """print ice cream flavors"""
        print("The flavors we offer are: " + str(self.flavors))
