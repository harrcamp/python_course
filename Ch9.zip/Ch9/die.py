# 9-14

from random import randint

class Die():
    """simulate a 6 sided die"""
    
    def __init__(self, sides):
        """initialize attributes of a die"""
        self.sides = sides
        
    def roll_die(self):
        """print the result of rolling a 6-sided die"""
        return randint(1,self.sides) 
        
die_6 = Die(6)

rolls_6 = []
for roll_6 in range(0,10):
    x = die_6.roll_die()
    rolls_6.append(x)

print(rolls_6)


die_10 = Die(10)

rolls_10 = []
for roll_10 in range(0,10):
    y = die_10.roll_die()
    rolls_10.append(y)
    
print(rolls_10)


die_20 = Die(20)

rolls_20 = []
for roll_20 in range(0,10):
    z = die_20.roll_die()
    rolls_20.append(z)
    
print(rolls_20)


