# admin

from users import User

class Privileges():
    """model of admin privileges of a user"""
    
    def __init__(self, privileges=['can add post', 'can delete post',
        'can ban user']):
        """initialize the privileges."""
        self.privileges = privileges

    def show_privileges(self):
        """show admin priviliges"""
        print("The administrator: " + str(self.privileges))
        
class Admin(User):
    """initialize the Admin subclass"""
    
    def __init__(self, first_name, last_name, age, location, worthy):
        """Initialize attributes of the parent class.
        Then initialize attributes specific to Admin
        """
        super().__init__(first_name, last_name, age, location, worthy)
        self.privileges = Privileges()
