#the first 2 in this function tells where to start the list, the 11 tells where to stop, 
#and the second 2 tells how many numbers to skip between each value 

even_numbers = list(range(2,11,2))
print(even_numbers)
