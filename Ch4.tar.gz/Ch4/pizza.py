pizzas = ["cheese", "mushroom", "pep"]
friend_pizzas = pizzas[:]

#add pizza to my list
pizzas.append('deep dish')

#add pizza to friends list
friend_pizzas.append('sausage')

#print my fave pizza
for friends_pizzas in friend_pizzas:
    print("My friend really likes " + friends_pizzas + " so much!\n")

#print my friends fave pizza
for pizza in pizzas:
    print("I like " + pizza + " so much!\n")
    
#print("I really like pizza!")










