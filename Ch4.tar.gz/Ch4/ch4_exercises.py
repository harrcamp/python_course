#4-3
#numbers_20 = [value+1 for value in range(0,20)]
#print(numbers_20)

#4-4 
#for value in range (1,1000001):
	#	print(value)
		
#4-5
#number_million_list = list(range(0,1000001))
#print(number_million_list)

#print(min(number_million_list))
#print(max(number_million_list))
#print(sum(number_million_list))

#4-6
#numbers_odd = [value for value in range(1,20,2)]
#print(numbers_odd)

#4-7
#numbers_threes = [value for value in range(3,31,3)]
#print(numbers_threes)

#4-8/4-9
#numbers_cubes = [value**3 for value in range(1,11)]
#print(numbers_cubes)
