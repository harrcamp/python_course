#buffet
buffet = ('meat loaf', 'steak', 'ribs', 'tacos', 'sausage')
for food in buffet:
	print(food.title())

#error
#buffet[0] = ('crab')

buffet = ('brisket', 'steak', 'ribs', 'chicken', 'sausage')
print('\nNew menu:')
for food in buffet:
	print(food.title())
