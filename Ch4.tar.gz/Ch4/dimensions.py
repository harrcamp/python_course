dimensions = (200, 50)
#print(dimensions[0])
#print(dimensions[1])

#cannot change values in a tuple - will receive error
dimensions[0] = 250

#can also loop through items in a tuple
#for dimension in dimensions:
#	print(dimension)

#redefine the tuble to change values
print("Original dimensions:")
for dimension in dimensions:
	print(dimension)
	
dimensions = (400,100)
print("\nModified dimensions:")
for dimension in dimensions:
	print(dimension)















