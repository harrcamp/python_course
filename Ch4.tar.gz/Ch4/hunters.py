hunters = ["lion", "tiger", "cheetah"]
for hunter in hunters:
	print(hunter.title() + "s are great hunters.")
	print(hunter.title() + "s are also a big cats.\n")
	
print("All of these animals would make great hunters.")
