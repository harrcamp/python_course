#copying lists

my_foods = ['pizza', 'falafel', 'carrot cake', 'fajitas', 'peanut butter']
friend_foods = my_foods[:]

#append lists to show they are seperate

my_foods.append('cannoli')
friend_foods.append('ice cream')
#

#print("My favorite foods are:")
#print(my_foods)

#print("\nMy friend's favorite foods are:")
#print(friend_foods)

#print("The first three items in the list are:")
#for food in my_foods[:3]:
#	print(food.title())

print("The last three items in the list are:")
for food in my_foods[-3:]:
	print(food.title())

print("\nThree items from the middle of my list are:")
for food in my_foods[1:4]:
	print(food.title())


