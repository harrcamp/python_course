#this works fine with a temporary variable but is unnecessarily long
squares = []
for value in range(1,11):
	square = value**2
	squares.append(square)
	
print(squares)

#same code written more concisely
squares = []
for value in range(1,11):
	squares.append(value**2)
	
print(squares)

#most efficient way to accompliush this - list comprehension
# list_name = [expression for loop range]

squares = [value**2 for value in range(1,11)]
print(squares)
