# HC - 1/22/2020
# This program produces a quote by Jordan B Peterson about aim and sight. It means one should focus on sight and be mindful of what is in focus.


famous_person = "- Jordan Peterson"
message = '"What you aim at determines what you see."\n\n'
print(message + " " + famous_person)
