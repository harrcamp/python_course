Nora = "NORA"
print(Nora.lower())
