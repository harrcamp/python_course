nora = " Nora " 
print(nora)
print(nora.rstrip())
