Nora = "Hello Nora, would you like to learn some Python today?"
print(Nora)

