# HC - 1/22/2020
# This program strips the white spaces from besides the text stored in the variable Nora

nora = " Nora " 
print(nora)
print(nora.strip())
