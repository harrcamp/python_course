fave_number = 2
print("My favorite number is" + " " + str(fave_number) + "!")
