Nora = "nora"
print(Nora.title())
