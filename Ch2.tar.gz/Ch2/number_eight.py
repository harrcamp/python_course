print(5+3)
print(10-2)
print(2**3)
print(16.0/2.0)
