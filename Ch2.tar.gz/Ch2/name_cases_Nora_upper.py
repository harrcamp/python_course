Nora_upper = "nora"
print(Nora_upper.upper())

