nora = " Nora " 
print(nora)
print(nora.lstrip())
