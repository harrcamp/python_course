first_name = "Jill"
last_name = "Rogowski"
full_name = first_name + " " + last_name

message = "Hello, " + full_name.title() + "!"
print(message)
