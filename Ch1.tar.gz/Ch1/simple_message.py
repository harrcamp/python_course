message = "reminder - look for studio space for rent"
print(message)
