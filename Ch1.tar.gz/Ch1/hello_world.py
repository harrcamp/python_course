message = "Hello Python World!"
print(message)

message = "Hello Python Crash Course world!"
print(message)
