message = "reminder - look for studio space to rent"
print(message)

message = "reminder - love yourself :)"
print(message)
