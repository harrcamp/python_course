#conditional_tests
# country = 'germany'
# print("Is country == 'germany'? I predict True.")
# print(country == 'germany')

# print("\nIs country == 'spain'? I predict False.")
# print(country == 'spain')

# pizza = 'cheese'
# print("\nIs pizza == 'pep'? I predict False.")
# print(country == 'pep')

# print("\nIs pizza == 'cheese'? I predict True.")
# print(pizza == 'cheese')

# car = 'toyota'
# print("\nIs car == 'honda'? I predict False.")
# print(car == 'honda')

# print("\nIs car == 'toyota'? I predict True.")
# print(car == 'toyota')

#book = 'Infinite Jest'
#print("\nIs book == 'Infinite Jest'? I predict True.")
#print(book == 'Infinite Jest')

#print("\nIs book == '12 Rules for Life'? I predict False.")
#print(book == 'False')

#music = 'Kanye'
#print("\nIs music == 'Kanye'? I predict True.")
#print(music == 'Kanye')

#print("\nIs music == 'Nav'? I predict False.")
#print(music == 'Nav')


# 5-2 more conditional tests

#change the value of the variable to activate the printed statement
# cookie = 'oatmeal raisin'
# if cookie != 'chocolate chip':
    # print("I like " + cookie +", but my favorite are chocolate chip!\n")

# name = 'HARRISON'
# if name == 'HARRISON':
    # print("The variable is stored as uppercase but printed lower case. \n" + name.lower())
# print(name)
# print(name == 'HARRISON')

# numerical test
# answer = 24
# print("The answer is not 22.")
# print(answer != 22)

# print("\nThe answer is less than 25.")
# print(answer < 25)

# print("\nThe answer is greater than 20.")
# print(answer > 20)

# print("\nThe answer is 24.")
# print(answer)

# answer_2 = 10
# answer_3 = 15
# print(answer_2)
# print(answer_3)
# print("The first number is greater than 8 and the second number is less than 20")
# print(answer_2 > 8 and answer_3 < 20)


# item not in a list
cars = ['toyota', 'honda', 'ford', 'chevy']
my_car = 'ferrari'

if my_car not in cars:
    print("These cars are crap, mine is a " + my_car.title())

# check whether an item is in a list
cars = ['toyota', 'honda', 'ford', 'chevy', 'ferrari']
my_car = 'ferrari'
if my_car in cars:
    print("Now that's a nice car.")
















