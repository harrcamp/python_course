# current users

current_users = ['harrycampbell', 'hpcampbell2', 'hpc710', 'admin', 'harry']

new_users = ['Harry', 'hpc710', 'omar', 'michal']

for new_user in new_users:
    if new_user.lower() in current_users:
        print("This username is already taken, please choose another.")
    else:
        print("Hi " + new_user + ", welcome to Cannacast!")














