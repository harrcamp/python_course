# alien_color_2

alien_color = 'green'

if alien_color == 'green':
    print('+5')
else:
    print('+10')


alien_color = 'blue'

if alien_color == 'green':
    print('+5')
else:
    print('+10')




