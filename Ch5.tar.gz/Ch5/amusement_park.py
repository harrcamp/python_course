#amusement park fares - if-elif-else

age = 12

if age < 4:
    print("Your admission costs $0.")
elif age < 18:
    print("Your admission cost is $5.")
else:
    print("Your admission cost is $10.")

# more concise code with addition of extra elif block for senior admission
# 

age = 70

if age < 4:
    price = 0
elif age < 18:
    price = 5
elif age < 65:
    price = 10
elif age >= 65:
    price = 5
    
print("Your admission cost is $" + str(price) + ".")
