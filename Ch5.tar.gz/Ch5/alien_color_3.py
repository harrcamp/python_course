# alien_color_3

alien_color = 'green'

if alien_color == 'green':
    print('+5')
elif alien_color == 'yellow':
    print('+10')
else:
    print('+15')

alien_color = 'yellow'

if alien_color == 'green':
    print('+5')
elif alien_color == 'yellow':
    print('+10')
else:
    print('+15')
    
alien_color = 'red'

if alien_color == 'green':
    print('+5')
elif alien_color == 'yellow':
    print('+10')
else:
    print('+15')
