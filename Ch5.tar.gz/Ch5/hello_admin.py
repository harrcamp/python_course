# hello admin - with users

usernames = ['admin', 'hpcampbell2']

if usernames:
    for user in usernames:
        if user == 'admin':
            print("Hello, Admin. Would you like a status update?")
        elif user in usernames:
            print("Hello, " + user + ". Thank you for logging in again.")
else:
    print("\nWe need more users.")
    
# hello admin - check to see if there are no users




