# 5-3 Alient colors #1

alien_color = 'green'

# successful test
if alien_color == 'green':
    print("+5")


alien_color = 'blue'

# successful test
if alien_color == 'green':
    print("+5")
