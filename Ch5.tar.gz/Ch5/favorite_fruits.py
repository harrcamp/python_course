# favorite fruit

favorite_fruites = ['grapes', 'apples', 'oranges']

if 'grapes' in favorite_fruites:
    print('Grapes!')
if 'apples' in favorite_fruites:
    print('Apples!')
if 'apples' in favorite_fruites:
    print('Oranges!')
if 'pineapple' in favorite_fruites:
    print('Pineapple!')
if 'berries' in favorite_fruites:
    print('Berries!')
    
print("\nYou really like fruit!") 
