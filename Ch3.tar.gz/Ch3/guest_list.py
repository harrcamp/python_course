dinner_guests = ['albert', 'teddy', 'john']

guest_1 = dinner_guests.pop(0)
guest_2 = dinner_guests.pop(1)
guest_3 = dinner_guests.pop(-1)

message_1 = (guest_1.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.\n") 
message_2 = (guest_2.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.\n") 
message_3 = (guest_3.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 

print(message_1)
print(message_2)
print(message_3)

number_of_guests = len(dinner_guests)
print(number_of_guests)




