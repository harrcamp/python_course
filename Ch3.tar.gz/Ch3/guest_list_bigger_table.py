dinner_guests = ['albert', 'teddy', 'john']

number_of_guests = len(dinner_guests)
message_number_of_guests = ("we will be having " + str(number_of_guests) + " guests join us this evening.\n")
print(message_number_of_guests)

del dinner_guests[-1]
dinner_guests.insert(-1, 'paul')
dinner_guests.insert(0, 'martin')
dinner_guests.insert(0, 'malcomb')
dinner_guests.append('abe')

guest_1 = dinner_guests[0]
guest_2 = dinner_guests[1]
guest_3 = dinner_guests[2]
guest_4 = dinner_guests[3]
guest_5 = dinner_guests[4]

message_1 = (guest_1.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 
message_2 = (guest_2.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 
message_3 = (guest_3.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 
message_4 = (guest_4.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 
message_5 = (guest_5.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 

message_6 = ("Unfortunately John can't make it anymore, instead Paul is coming to join us.")
message_7 = ("However we did find a larger table so Martin, Malcomb, and Abe will now be joining us.\n")

print(message_1 + " " + message_6 + " " + message_7)
print(message_2 + " " + message_6 + " " + message_7)
print(message_3 + " " + message_6 + " " + message_7)
print(message_4 + " " + message_6 + " " + message_7)
print(message_5 + " " + message_6 + " " + message_7)
