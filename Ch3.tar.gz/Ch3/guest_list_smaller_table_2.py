dinner_guests = ['albert', 'teddy', 'john']
dinner_guests.insert(0, 'abe')
dinner_guests.insert(0, 'martin')
 
message_small_table = ("Hi All, unfortunately my larger table has not arrived so we can not have dinner this month. We will reschedule though!")

popped_guest_1 = dinner_guests.pop()
message_small_table_1 = ("Hi " + popped_guest_1.title() + ", Sorry for this but we have to cancel dinner. My table has not arrived yet!\n") 
print(message_small_table_1)

popped_guest_2 = dinner_guests.pop()
message_small_table_2 = ("Hi " + popped_guest_2.title() + ", Sorry for this but we have to cancel dinner. My table has not arrived yet!\n") 
print(message_small_table_2)

popped_guest_3 = dinner_guests.pop()
message_small_table_3 = ("Hi " + popped_guest_3.title() + ", Sorry for this but we have to cancel dinner. My table has not arrived yet!\n") 
print(message_small_table_3)

del dinner_guests[0]
del dinner_guests[0]
print(dinner_guests)

number_of_guests = len(dinner_guests)
message_number_of_guests = ("We will be inviting" + "number_of_guests" + "to dinner this evening.")
print(number_of_guests)
