mana = ['swamp', 'mountain', 'island', 'sky', 'earth']
print(mana)

mana.remove('sky')
print(mana)

del mana[-1]
print(mana)

mana.insert(0, 'plains')
mana.append('forest')
print(mana)

mana_sources = len(mana)
correct_list = ("\nThe list of mana sources is now accurate. There are " + str(mana_sources) + " total mana sources.")
print(correct_list)

print(sorted(mana))
print(mana)

mana.sort()
print(mana)
mana.sort(reverse=True)
print(mana)

mana.reverse()
print(mana)

popped_mana_1 = mana.pop()
msg_mana_purpose = ("\nThe purpose of a mana source, such as a " + popped_mana_1 + ", is to give power to the plainswalker for spellcasting.")
print(msg_mana_purpose)

print(mana)
mana.append('swamp')
print(mana)
