dinner_guests = ['albert', 'teddy', 'john']
del dinner_guests[-1]
dinner_guests.insert(-1, 'paul')

guest_1 = dinner_guests[0]
guest_2 = dinner_guests[1]
guest_3 = dinner_guests[2]

message_1 = (guest_1.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 
message_2 = (guest_2.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 
message_3 = (guest_3.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.") 
message_4 = ("Unfortunately John can't make it anymore, instead Paul is coming to join us.\n")

print(message_1 + " " + message_4)
print(message_2 + " " + message_4)
print(message_3 + " " + message_4)






