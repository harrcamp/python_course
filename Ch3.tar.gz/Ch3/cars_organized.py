cars = ['bmw', 'audi', 'toyota', 'subaru']
print('here is the original list')
print(cars)

print("\nHere is the sorted list:")
print(sorted(cars))

print("\nHere is the original list again:")
print(cars)

cars.reverse()
print(cars)
