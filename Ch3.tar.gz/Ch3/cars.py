cars = ['ferrari', 'lamborghini', 'porsche', 'jaguar']
message_1 = "If I had the money right now I would buy a " + cars[1].title() + ".\n"
message_2 = "When I get older and do have the money I will buy a " + cars[-1].title() + ".\n"
message_3 = "When I am much older and have plenty of money I will buy a " + cars[0].title() + ".\n"
message_4 = "Realistically when I am much older and have enough money for a " + cars[0].title() + " I will buy a " + cars[2].title() + ".\n"
print(message_1)
print(message_2)
print(message_3)
print(message_4)
