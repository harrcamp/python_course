locations = ['portugal', 'spain', 'italy', 'germany', 'finland']

print(sorted(locations))
print(locations)
print("\n")

locations.reverse()
print(locations)
locations.reverse()
print(locations)
print("\n")

locations.sort()
print(locations)
print("\n")

locations.sort(reverse=True)
print(locations)




