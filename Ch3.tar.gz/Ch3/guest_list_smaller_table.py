dinner_guests = ['albert', 'teddy', 'john']
del dinner_guests[-1]
dinner_guests.insert(0, 'paul')
dinner_guests.insert(0, 'martin')
dinner_guests.insert(0, 'malcomb')
dinner_guests.append('abe')

popped_guest_1 = dinner_guests.pop()
popped_guest_2 = dinner_guests.pop()

guest_1 = popped_guest_1
guest_2 = popped_guest_2
guest_3 = dinner_guests[0]
guest_4 = dinner_guests[1]
guest_5 = dinner_guests[2]

message_1 = (guest_1.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.\n") 
message_2 = (guest_2.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.\n") 
message_3 = (guest_3.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.\n") 
message_4 = (guest_4.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.\n") 
message_5 = (guest_5.title() + "! I would like to invite you for dinner this month. Others will be joing who I think you will enjoy speaking with.\n") 

message_6 = ("Hi " + guest_3.title() + ",\n\n" + "Unfortunately I will have to cancel dinner for this month, sorry for the trouble here. We will definitely reschedule soon.\n")
message_7 = ("Hi " + guest_4.title() + ",\n\n" + "Unfortunately I will have to cancel dinner for this month, sorry for the trouble here. We will definitely reschedule soon.\n")
message_8 = ("Hi " + guest_5.title() + ",\n\n" + "Unfortunately I will have to cancel dinner for this month, sorry for the trouble here. We will definitely reschedule soon.\n")

print(message_1)
print(message_2)
print(message_6)
print(message_7)
print(message_8)

