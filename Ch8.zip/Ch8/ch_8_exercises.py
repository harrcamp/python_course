# ch 8 exercises

# 8-1

# def display_message():
    # """Tell people what I am learning in this chapter."""
    # print("I am learning about functions in this chapter.")
    
# display_message()

# 8-2

# def favorite_book(title):
    # """Prints the favorite book input arguement"""
    # print("One of my favorite books is " + title + ".")
    
# favorite_book('Infinite Jest')

# 8-3

# def make_shirt(shirt_size='L', shirt_text='I love Python'):
    # """print the size and text on a shirt"""
    # print("\nThe size of your shirt is " + shirt_size + ".")
    # print("The text on the shirt reads " + shirt_text + ".")

# make_shirt()
# make_shirt(shirt_text='go bern go')
# make_shirt(shirt_size='M')


# 8-4 edits 8-3

# 8-5 

# def describe_city(city_name, city_country='Germany'):
    # """which country are cities located in"""
    # print(city_name + " is in " + city_country + ".")
    
# describe_city(city_name='Frankfurt')
# describe_city(city_name='Berlin')
# describe_city(city_name='Vienna', city_country='Austria')

# 8-6

# def city_country(name_city, name_country):
    # """format the name of a city and it's country"""
    # full_name = '"' + name_city + ", " + name_country + '"'
    # return full_name.title()
    
# location = city_country('santiago', 'chile')
# print(location)
    
# 8-7

# def make_album(album_name, album_artist, tracks=''):
    # """return a dictionary of information about an album"""
    # album = {'name': album_name, 'artist': album_artist}
    # if tracks:
        # album['tracks'] = tracks
    # return album
    
# while True:
    # print("\nWhat is the name of the album?")
    # print("(enter 'q' at any time to quit)")
    
    # a_name = input("Album name: ")
    # if a_name == 'q':
        # break
        
    # a_artist = input("Album artist: ")
    # if a_name == 'q':
        # break
    
    # project = make_album(a_name.title(), a_artist.title())
    # print(project)

# 8-8 modified 8-7

# 8-9 

# def show_magicians(names):
    # """print magicians names in a list"""
    # for name in names:
        # magician = name.title()
        # print(magician)
        
# magicians = ['david', 'penn', 'teller']

# show_magicians(magicians)

# print(magicians)

# 8-10 

# def show_magicians(magicians, great_magicians):
    # """print magicians names in a list"""
    # while magicians:
        # magician_in_progress = magicians.pop()
        # print("Making this magician great: " 
        # + magician_in_progress.title())
        # great_magicians.append("The Great " 
        # + magician_in_progress.title())
        
# def make_great(great_magicians):
    # """make magicians great"""
    # print("\nPresenting the best magicians ever!")
    # for great_magician in great_magicians:
        # print(great_magician.title())
        
# magicians = ['david', 'penn', 'teller']
# great_magicians = []

# show_magicians(magicians[:], great_magicians)
# make_great(great_magicians)

# print(great_magicians)
# print(magicians)

# 8-12

# def make_sandwich(meat, *toppings):
    # """Summarize the sandwich we are about to make."""
    # print("\nMaking a " + meat + 
        # " sandwich with the following toppings:")
    # for topping in toppings:
        # print("- " + topping)
    
# make_sandwich('ham', 'tomato')
# make_sandwich('turkey', 'cheddar','green peppers', 'extra cheese')
# make_sandwich('ham', 'tomato', 'mayo')

# 8-13

# def build_profile(first, last, **user_info):
    # """Build a dictionary containing everything we know about a user."""
    # profile = {}
    # profile['first_name'] = first
    # profile['last_name'] = last
    # for key, value in user_info.items():
        # profile[key] = value
    # return profile
    
# user_profile = build_profile('harrison', 'campbell',
                            # location='chicago',
                            # company='EY')
# print(user_profile)

# 8-14

# def make_car(manufacturer, model, **add_ons):
    # """show the characteristics of a car"""
    # car = {}
    # car['manufacturer_name'] = manufacturer
    # car['model_name'] = model
    # for key, value in add_ons.items():
        # car[key] = value
    # return car
    
# finished_car = make_car('toyota', 'land cruiser',
                                    # third_row=True)

# print(finished_car)

# 8-15 see funcion printing_functions.py and printing_models.py


















