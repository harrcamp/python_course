

# import profile_functions
# user_profile = profile_functions.build_profile('albert', 'einstein',
                            # location='princeton',
                            # field='physics')
# print(user_profile)


# from profile_functions import build_profile
# user_profile = build_profile('albert', 'einstein',
                            # location='princeton',
                            # field='physics')
# print(user_profile)


# from profile_functions import build_profile as bp
# user_profile = bp('albert', 'einstein',
                            # location='princeton',
                            # field='physics')
# print(user_profile)


# import profile_functions as pf
# user_profile = pf.build_profile('albert', 'einstein',
                            # location='princeton',
                            # field='physics')
# print(user_profile)


from profile_functions import *
user_profile = build_profile('albert', 'einstein',
                            location='princeton',
                            field='physics')
print(user_profile)









































